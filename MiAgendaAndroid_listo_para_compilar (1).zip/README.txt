MI AGENDA — PROYECTO ANDROID

Este paquete contiene el proyecto fuente para generar una APK instalable con Android Studio.
No es una APK compilada: este entorno no tiene instalado Android SDK/Gradle y no tiene acceso a Internet para descargar las herramientas necesarias.

Funciones incluidas:
- Agenda de compromisos, fecha/hora y recordatorio mientras la aplicación está activa.
- Contactos guardados en el dispositivo e importación de contactos del teléfono con permiso.
- Acciones para llamar y abrir WhatsApp.
- Crear una cita desde un contacto.
- Búsqueda, edición, eliminación y exportación/importación de respaldo JSON.
- Interfaz en español adaptada a móvil.

Cómo generar la APK:
1. Instala Android Studio en una computadora.
2. Descomprime esta carpeta.
3. En Android Studio selecciona Open y abre la carpeta MiAgendaAndroid.
4. Acepta la instalación del Android SDK que Android Studio solicite y espera a que termine Gradle Sync.
5. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
6. La APK debug se encontrará en app/build/outputs/apk/debug/app-debug.apk.

Importante:
- Los avisos de esta primera versión se revisan mientras la aplicación permanece abierta; Android puede limitar avisos si se cierra la app.
- Llamar abre el marcador del teléfono para que confirmes la llamada; no inicia llamadas automáticas.
- Los datos quedan en el dispositivo. Exporta un respaldo para no perderlos.
